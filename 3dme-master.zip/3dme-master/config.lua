-- ## 3dme : shared config file

Config = {
    language = 'es',
    visual = {
        color = { r = 230, g = 230, b = 230, a = 255 }, -- Text color
        font = 0, -- Text font
        time = 5000, -- Duration to display the text (in ms)
        scale = 0.5, -- Text scale
        dist = 250, -- Min. distance to draw 
    },
}

Languages = {
    ['en'] = {
        commandName = 'me',
        commandDescription = 'Display an action above your head.',
        commandSuggestion = {{ name = 'action', help = '"scratch his nose" for example.'}},
        prefix = 'the person '
    },
    ['fr'] = {
        commandName = 'me',
        commandDescription = 'Affiche une action au dessus de votre tête.',
        commandSuggestion = {{ name = 'action', help = '"se gratte le nez" par exemple.'}},
        prefix = 'l\'individu '
    },
    ['es'] = {
        commandName = 'me',
        commandDescription = 'Pon una accion ensima de tu cabeza',
        commandSuggestion = {{ name = 'action', help = '"por ejemplo /me le pica un huevo ctm duketo'}},
        prefix = 'the person '
    },
    
}
