fx_version 'bodacious'
game 'gta5'

author 'FishyDEV'
ui_page 'html/index.html'

client_scripts {
  'client.lua',
}

server_scripts {
  'server.lua',
}

files {
  "html/*.html",
  "html/*.css",
  "html/*.js",
  "html/*.ttf",
}