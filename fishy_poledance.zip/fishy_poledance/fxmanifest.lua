fx_version 'adamant'
game 'gta5'
author 'FishyDEV'
description 'Fishy PoleDance'
version '1.0.0'

client_scripts {
	'config.lua',
	'client.lua',
}